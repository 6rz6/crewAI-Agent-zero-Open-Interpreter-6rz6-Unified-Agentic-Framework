~~~json
{
    "system_warning": "Tool {{tool_name}} not found. Available tools: \n{{tools_prompt}}"
}
~~~