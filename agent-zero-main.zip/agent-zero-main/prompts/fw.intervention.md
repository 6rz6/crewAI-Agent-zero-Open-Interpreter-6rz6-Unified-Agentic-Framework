~~~json
{
    "user_intervention": "{{user_message}}"
}
~~~