~~~json
{
    "system_error": "{{error}}"
}
~~~