~~~json
{
    "system_warning": "You have sent the same message again. You have to do something else!"
}
~~~